# Feynn-Labs-Internship
Project 2.0 - Case Study on Market Segmentation with implementation using McDonald's dataset
